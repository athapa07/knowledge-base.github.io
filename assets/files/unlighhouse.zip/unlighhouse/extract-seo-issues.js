// extract-seo-issues.js
import fs from 'fs';
import path from 'path';

const REPORTS_DIR = '.unlighthouse';
const issuesByAudit = {};
let filesProcessed = 0;

function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full);
    else if (entry.name === 'lighthouse.json') {
      processReport(full);
    }
  }
}

function processReport(filePath) {
  const data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
  const lhResult = data.report || data.lhr || data;
  const url = lhResult.finalUrl || lhResult.requestedUrl || filePath;
  const audits = lhResult.audits || {};
  const seoRefs = lhResult.categories?.seo?.auditRefs || [];

  if (seoRefs.length === 0) {
    console.warn(`No SEO auditRefs found in ${filePath}`);
    return;
  }

  filesProcessed++;

  for (const ref of seoRefs) {
    const audit = audits[ref.id];
    if (!audit || audit.score === 1 || audit.score === null) continue;

    if (!issuesByAudit[ref.id]) {
      issuesByAudit[ref.id] = {
        title: audit.title,
        description: audit.description,
        impact: audit.score === 0 ? 'Fail' : 'Partial',
        pages: [],
      };
    }
    issuesByAudit[ref.id].pages.push(url);
  }
}

walk(REPORTS_DIR);

const rows = [['Issue', 'Severity', 'Description', 'Affected Pages', 'Page Count']];
for (const [id, issue] of Object.entries(issuesByAudit)) {
  rows.push([
    issue.title,
    issue.impact,
    issue.description.replace(/\n/g, ' '),
    issue.pages.join(' | '),
    issue.pages.length,
  ]);
}

const csv = rows.map(r => r.map(c => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n');
fs.writeFileSync('seo-issues.csv', csv);
console.log(`Processed ${filesProcessed} report files.`);
console.log(`Found ${Object.keys(issuesByAudit).length} distinct SEO issues.`);