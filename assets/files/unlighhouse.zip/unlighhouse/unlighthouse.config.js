export default {
  site: 'example.com.au',
  scanner: {
    device: 'desktop',
  },
  // 'performance', 'accessibility', 'best-practices', 'seo'
  lighthouseOptions: {
    onlyCategories: ['performance'],
  },
  ci: {
    buildStatic: true,
  },
}
